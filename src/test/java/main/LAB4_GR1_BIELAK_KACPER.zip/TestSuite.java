package main;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        Problem1Test.class,
        Problem2Test.class,
        Problem4Test.class,
        Problem9Test.class,
        Problem10Test.class,
        Problem11Test.class,
        Problem12Test.class,
        Problem14Test.class,
        Problem15Test.class,
        Problem189Test.class,
        Problem233Test.class,
        Problem235Test.class,
        Problem138Test.class

})
class TestSuite { }
